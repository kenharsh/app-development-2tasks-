const appVersion = '7.4.0';
